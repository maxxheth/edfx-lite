const articleElem = document.getElementsByTagName('article')[0];

articleElem.parentNode.removeChild(articleElem);